			var doorIsOpen = false;
			function activateDoor(){
				if(doorIsOpen){
					document.getElementById('door').setAttribute("class", "closedDoor");
					doorIsOpen=false;
				} else{
					document.getElementById('door').setAttribute("class", "openedDoor");
					doorIsOpen=true;
				}
			}
			
			var plateIsShown = false;
			function activatePlate(){
				if(plateIsShown){
					document.getElementById('plate').setAttribute("class", "plate");
					plateIsShown=false;
				} else{
					document.getElementById('plate').setAttribute("class", "showPlate");
					plateIsShown=true;
				}
			}